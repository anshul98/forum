<html><body>
<a href=test.html#1>go there</a>
</body>
</html>