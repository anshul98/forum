<div class="container-fluid" id="headertitlewrap"><!-- headertitlewrap -->
	<div class="col-xs-12" id="headertitleinnerwrap"><!-- headertitleinnerwrap -->
		<div class="col-xs-4" id="brandnamediv">
			<p id="brandname">MMNIT FORUMS</p>
		</div>
		<div class="col-sm-5 col-sm-push-3" id="navmenu">
			<?php require('navbar.php');?>
		</div>

	</div><!-- end of headertitleinnerwrap -->
</div><!-- end of headertitlewrap -->


<div class="container-fluid" id="headerwrap"><!-- header wrapper -->
	<div class="col-sm-12" id="headinnerwrap"><!-- headinner wrap -->
	
		<div class="col-sm-12" id="searchdiv"><!-- search div -->
		<div class="row">
			<div class="col-sm-3" id="search">	<!-- search -->
				<form>	
					<fieldset>
						<input type="text" placeholder="Search" required id="searchfield" class="col-sm-9"></input>
						<button type="submit" id="searchbutton"><span class="fa fa-search" class="col-sm-3"></span></button>
					</fieldset>
				</form>
			</div> <!-- end of search -->
			<div class="col-sm-3 col-sm-push-5" id="logoutdiv"><!--logout div-->
				<p style="text-align: right;margin:0;padding-right:5%"><span><i class="fa fa-power-off"></i><a href="#" id="logout">Logout</a></span></p>
			</div><!-- end of logout div-->
		</div>
		</div><!-- end of search div -->
	
	</div><!-- end of headinner wrap -->
</div><!-- end of header wrapper -->