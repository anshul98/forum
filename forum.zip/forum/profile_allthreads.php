<div class="row no-margin-padding" style="overflow-y:scroll;height: 360px;"><!-- inner threads row -->
<div class="col-sm-12" id="_threadcontent"><!-- threadcontent-->
 
  <div class="row" id="singlethread_" style="background: white"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->


  <div class="row" id="singlethread_" style="background: #eee"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->



  <div class="row" id="singlethread_" style="background: white"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->


  <div class="row" id="singlethread_" style="background: #eee"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->


  <div class="row" id="singlethread_" style="background: white"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->


  <div class="row" id="singlethread_" style="background: #eee"><!--singlethread-->
    <div class="col-sm-6 no-margin-padding" id="singlethread_1"><!-- single thread 1st col-->
        <div class="col-sm-1 no-margin-padding" id="icon_1"><span class="fa fa-comment" style="font-size: 30px;color:#ddd"></span></div>
        <div class="col-sm-11 no-margin-padding" id="singletopic_1"><!-- singletopic_1-->
            <div class="col-sm-12 no-margin-padding"><a href="#">Web Developement</a></div>
            <div class="col-sm-12 no-margin-padding"><p>Small Description about the topic</p></div>
        </div><!--end of singletopic_1-->
    </div><!--end of single thread 1st col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_2"><!-- single thread 2 col-->
      <div class="col-sm-12 no-margin-padding"><p style="text-align: center;margin-bottom: 0;"><b>By: </b>Alphaguy3</p></div>
    </div><!--end of single thread 2 col-->
    <div class="col-sm-3 no-margin-padding" id="singlethread_3"><!-- single thread 3 col-->
      <div class="col-sm-12 no-margin-padding" style="padding: 10px;"><center><button class="btn">Join</button></center></div>
    </div><!--end of single thread 3 col-->
  </div><!--end of singlethread-->

</div><!-- threadcontent-->
</div><!-- inner threads row -->