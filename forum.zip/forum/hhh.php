<?php
header('location:https://api.instagram.com/oauth/authorize/?client_id=c50671f7be4f4443ac7d7b2e5d6c4ddb&redirect_uri=localhost:8000/ins.php&response_type=code');
?>
